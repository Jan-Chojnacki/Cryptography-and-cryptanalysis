//! Moduły odpowiedzialne za analizy statystyczne oraz ataki na szyfry.

pub mod bruteforce;
mod x2test;
