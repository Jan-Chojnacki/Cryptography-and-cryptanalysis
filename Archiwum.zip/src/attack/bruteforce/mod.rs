//! Implementacje ataków brute force na obsługiwane algorytmy szyfrujące.

pub mod affine;
pub mod transposition;
