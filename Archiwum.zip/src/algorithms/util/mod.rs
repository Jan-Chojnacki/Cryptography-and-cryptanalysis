//! Wspólne narzędzia pomocnicze wykorzystywane przez implementacje algorytmów.

pub mod substitute;
